CREATE DATABASE user;

CREATE TABLE `members` (
  `uname` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO members (uname,pass)
VALUES ('harshil','harsh');

INSERT INTO members (uname,pass)
VALUES ('anuj','anuj123');

CREATE TABLE `prods` (
  `uname` varchar(45) NOT NULL,
  `prod` varchar(45) NOT NULL,
  `price` integer(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO prods (uname,prod,price)
VALUES ('harshil','Apple',18000);

CREATE TABLE image ( id int NOT NULL AUTO_INCREMENT,
`title` varchar(50),
`image` blob,
PRIMARY KEY (id) 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


